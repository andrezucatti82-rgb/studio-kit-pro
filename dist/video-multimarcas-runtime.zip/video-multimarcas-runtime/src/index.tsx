import React from 'react';
import {Composition,registerRoot} from 'remotion';
import {Film,Project} from './Film';
import {buildTimeline} from './timeline.mjs';
import template from '../templates/project.json';
const Root=()=> <Composition id="BrandFilm" component={Film} width={1080} height={1920} fps={30} durationInFrames={buildTimeline(template.scenes).durationInFrames} defaultProps={template as Project} calculateMetadata={({props}:{props:Project})=>({fps:props.fps,durationInFrames:buildTimeline(props.scenes).durationInFrames})}/>;
registerRoot(Root);
